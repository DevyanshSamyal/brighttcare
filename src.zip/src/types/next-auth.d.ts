import { SectionType, Role } from "@prisma/client";
import "next-auth";
import "next-auth/jwt";

declare module "next-auth" {
  interface User {
    id: string;
    username: string;
    name: string;
    role: Role;
    sections: SectionType[];
  }

  interface Session {
    user: {
      id: string;
      username: string;
      name: string;
      role: Role;
      sections: SectionType[];
    };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    username: string;
    name: string;
    role: Role;
    sections: SectionType[];
  }
}
