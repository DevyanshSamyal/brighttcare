import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { ChangePasswordForm } from "@/components/ChangePasswordForm";
import { TopNav } from "@/components/TopNav";

export default async function AccountPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const backHref = session.user.role === "ADMIN" ? "/admin/dashboard" : "/doctor/dashboard";

  return (
    <div className="min-h-screen bg-paper">
      <TopNav name={session.user.name} roleLabel={session.user.role === "ADMIN" ? "Admin" : "Doctor"} />
      <main className="max-w-5xl mx-auto px-4 py-6 space-y-4">
        <Link href={backHref} className="text-sm text-ink-soft hover:text-pine">
          ← Back
        </Link>
        <h1 className="font-display text-2xl font-semibold text-ink">Account</h1>
        <p className="text-sm text-ink-soft">
          Signed in as <span className="font-medium text-ink">{session.user.name}</span>
        </p>
        <ChangePasswordForm />
      </main>
    </div>
  );
}
