import { notFound } from "next/navigation";
import { SECTIONS } from "@/lib/sections";
import { SectionForm } from "@/components/SectionForm";
import type { SectionType } from "@prisma/client";

export default async function DoctorSectionEntryPage({
  params,
}: {
  params: Promise<{ studentId: string; section: string }>;
}) {
  const { studentId, section } = await params;
  if (!(section in SECTIONS)) notFound();
  return <SectionForm studentId={studentId} section={section as SectionType} backHref="/doctor/dashboard" />;
}
