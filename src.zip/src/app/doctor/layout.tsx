import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { TopNav } from "@/components/TopNav";

export default async function DoctorLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "DOCTOR") redirect("/login");

  return (
    <div className="min-h-screen bg-paper">
      <TopNav name={session.user.name} roleLabel="Doctor" />
      <main className="max-w-5xl mx-auto px-4 py-6">{children}</main>
    </div>
  );
}
