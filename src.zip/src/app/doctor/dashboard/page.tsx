"use client";

import { useEffect, useState, useCallback } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { SECTIONS } from "@/lib/sections";
import { SectionStamp } from "@/components/SectionStamp";
import type { SectionStatus, SectionType } from "@prisma/client";

interface StudentRow {
  id: string;
  name: string;
  rollNumber: string;
  admissionNumber: string;
  class: { grade: string; section: string; schoolName: string };
  mySections: { section: SectionType; status: SectionStatus }[];
}

export default function DoctorDashboard() {
  const { data: session } = useSession();
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback((q: string) => {
    setLoading(true);
    const params = q ? `?q=${encodeURIComponent(q)}` : "";
    fetch(`/api/students${params}`)
      .then((r) => r.json())
      .then((data) => setStudents(data.students ?? []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const t = setTimeout(() => load(query), 250);
    return () => clearTimeout(t);
  }, [query, load]);

  const mySectionCount = session?.user.sections.length ?? 0;

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display text-2xl font-semibold text-ink">Your students</h1>
        <p className="text-sm text-ink-soft mt-0.5">
          {mySectionCount > 1
            ? `Assigned to ${session?.user.sections.map((s) => SECTIONS[s].label).join(" & ")}`
            : session?.user.sections[0]
            ? `Assigned to ${SECTIONS[session.user.sections[0]].label}`
            : "No section assigned yet — ask your admin."}
        </p>
      </div>

      <input
        className="field-input mb-4 max-w-sm"
        placeholder="Search by name, roll no., or admission no."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      {loading ? (
        <p className="text-sm text-ink-soft py-8 text-center">Loading…</p>
      ) : students.length === 0 ? (
        <p className="text-sm text-ink-soft py-8 text-center">No students found.</p>
      ) : (
        <div className="card divide-y divide-mist">
          {students.map((s) => (
            <div key={s.id} className="flex items-center justify-between gap-4 px-4 py-3">
              <div className="min-w-0">
                <p className="text-sm font-medium text-ink truncate">{s.name}</p>
                <p className="text-xs text-ink-soft font-mono truncate">
                  Roll {s.rollNumber} · {s.class.grade}-{s.class.section} · {s.class.schoolName}
                </p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                {s.mySections.map(({ section, status }) => (
                  <Link
                    key={section}
                    href={`/doctor/students/${s.id}/${section}`}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <SectionStamp status={status} />
                    {mySectionCount > 1 && (
                      <span className="text-[10px] text-ink-soft group-hover:text-pine">
                        {SECTIONS[section].shortLabel}
                      </span>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
