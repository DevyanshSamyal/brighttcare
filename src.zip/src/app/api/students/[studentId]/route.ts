import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";
import { logAudit } from "@/lib/audit";
import { Gender } from "@prisma/client";

type Ctx = { params: Promise<{ studentId: string }> };

export async function GET(_req: NextRequest, { params }: Ctx) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const student = await prisma.student.findUnique({
      where: { id: studentId },
      include: {
        class: { include: { school: true } },
        generalExam: true,
        ent: true,
        vision: true,
        dental: true,
      },
    });
    if (!student) return NextResponse.json({ error: "Student not found" }, { status: 404 });
    return NextResponse.json({ student });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

const updateSchema = z.object({
  name: z.string().trim().min(1).optional(),
  rollNumber: z.string().trim().min(1).optional(),
  admissionNumber: z.string().trim().min(1).optional(),
  parentage: z.string().trim().min(1).optional(),
  gender: z.nativeEnum(Gender).optional(),
  mobileNumber: z.string().trim().min(1).optional(),
  examinationDate: z.string().datetime().optional().nullable(),
  medicalOfficerName: z.string().trim().optional().nullable(),
});

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try {
    const session = await requireAdmin();
    const { studentId } = await params;
    const data = updateSchema.parse(await req.json());
    const student = await prisma.student.update({
      where: { id: studentId },
      data: {
        ...data,
        examinationDate: data.examinationDate ? new Date(data.examinationDate) : data.examinationDate,
      },
    });
    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "STUDENT_UPDATE",
      studentId: student.id,
      detail: data,
    });
    return NextResponse.json({ student });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  try {
    const session = await requireAdmin();
    const { studentId } = await params;
    const student = await prisma.student.findUnique({ where: { id: studentId } });
    await prisma.student.delete({ where: { id: studentId } });
    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "STUDENT_DELETE",
      detail: { name: student?.name, rollNumber: student?.rollNumber },
    });
    return NextResponse.json({ ok: true });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
