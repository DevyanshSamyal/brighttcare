import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSectionAccess, jsonError, PermissionError } from "@/lib/permissions";
import { logAudit } from "@/lib/audit";
import { SECTIONS, allFieldKeys } from "@/lib/sections";
import { isSectionDataComplete } from "@/lib/completeness";
import { getSectionRecord, upsertSectionRecord, markSectionAbsent } from "@/lib/sectionRecords";
import { SectionType } from "@prisma/client";

type Ctx = { params: Promise<{ studentId: string; section: string }> };

function parseSection(raw: string): SectionType {
  if (!(raw in SECTIONS)) throw new PermissionError("Unknown section", 404);
  return raw as SectionType;
}

export async function GET(_req: NextRequest, { params }: Ctx) {
  try {
    const { studentId, section: rawSection } = await params;
    const section = parseSection(rawSection);
    await requireSectionAccess(section);

    const student = await prisma.student.findUnique({
      where: { id: studentId },
      select: {
        id: true,
        name: true,
        rollNumber: true,
        admissionNumber: true,
        class: { select: { grade: true, section: true, school: { select: { name: true } } } },
      },
    });
    if (!student) return NextResponse.json({ error: "Student not found" }, { status: 404 });

    const record = await getSectionRecord(studentId, section);
    return NextResponse.json({ student, record, sectionDef: SECTIONS[section] });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

export async function PUT(req: NextRequest, { params }: Ctx) {
  try {
    const { studentId, section: rawSection } = await params;
    const section = parseSection(rawSection);
    const session = await requireSectionAccess(section);
    const body = await req.json();

    const student = await prisma.student.findUnique({ where: { id: studentId }, select: { id: true } });
    if (!student) return NextResponse.json({ error: "Student not found" }, { status: 404 });

    if (body.markAbsent) {
      const record = await markSectionAbsent(studentId, section, session.user.name);
      await logAudit({
        userId: session.user.id,
        userName: session.user.name,
        action: "SECTION_MARK_ABSENT",
        studentId,
        section,
      });
      return NextResponse.json({ record });
    }

    // Only accept keys that belong to this section's field config — never
    // trust the client for anything beyond that (no status, no student id).
    const allowedKeys = new Set(allFieldKeys(section));
    const fields: Record<string, unknown> = {};
    for (const key of Object.keys(body.data ?? {})) {
      if (allowedKeys.has(key)) fields[key] = body.data[key];
    }

    // Numbers arrive as strings from form inputs — coerce height/weight.
    if ("heightCm" in fields) fields.heightCm = fields.heightCm === "" ? null : Number(fields.heightCm);
    if ("weightKg" in fields) fields.weightKg = fields.weightKg === "" ? null : Number(fields.weightKg);

    const complete = isSectionDataComplete(section, fields);
    const record = await upsertSectionRecord(
      studentId,
      section,
      fields,
      complete ? "COMPLETE" : "PENDING",
      session.user.name
    );

    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "SECTION_SAVE",
      studentId,
      section,
      detail: { status: complete ? "COMPLETE" : "PENDING" },
    });

    return NextResponse.json({ record });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
