import { NextRequest, NextResponse } from "next/server";
import { renderToBuffer } from "@react-pdf/renderer";
import React from "react";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";
import { logAudit } from "@/lib/audit";
import { SECTION_ORDER } from "@/lib/sections";
import { sectionStatus } from "@/lib/sectionRecords";
import { StudentRecordPdf } from "@/lib/pdf/StudentRecordPdf";
import type { SectionType } from "@prisma/client";

type Ctx = { params: Promise<{ studentId: string }> };

export async function GET(_req: NextRequest, { params }: Ctx) {
  try {
    const session = await requireAdmin();
    const { studentId } = await params;

    const student = await prisma.student.findUnique({
      where: { id: studentId },
      include: {
        class: { include: { school: true } },
        generalExam: true,
        ent: true,
        vision: true,
        dental: true,
      },
    });
    if (!student) return NextResponse.json({ error: "Student not found" }, { status: 404 });

    const statuses = {} as Record<SectionType, "PENDING" | "COMPLETE" | "ABSENT">;
    for (const section of SECTION_ORDER) statuses[section] = sectionStatus(section, student);

    const unresolved = SECTION_ORDER.filter((s) => statuses[s] === "PENDING");
    if (unresolved.length > 0) {
      return NextResponse.json(
        { error: `These sections aren't finished yet: ${unresolved.join(", ")}` },
        { status: 400 }
      );
    }
    if (!student.examinationDate || !student.medicalOfficerName) {
      return NextResponse.json(
        { error: "Set the examination date and medical officer name for this student before generating the PDF" },
        { status: 400 }
      );
    }

    const records = {
      GENERAL_EXAM: student.generalExam as Record<string, unknown> | null,
      ENT: student.ent as Record<string, unknown> | null,
      VISION: student.vision as Record<string, unknown> | null,
      DENTAL: student.dental as Record<string, unknown> | null,
    };

    const generatedAt = new Date();
    const buffer = await renderToBuffer(
      React.createElement(StudentRecordPdf, {
        student,
        records,
        statuses,
        generatedAt,
      })
    );

    await prisma.student.update({
      where: { id: student.id },
      data: { pdfGeneratedAt: generatedAt, pdfGeneratedBy: session.user.name },
    });
    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "PDF_GENERATE",
      studentId: student.id,
    });

    const fileName = `${student.name.replace(/[^a-z0-9]+/gi, "_")}_${student.rollNumber}.pdf`;
    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${fileName}"`,
      },
    });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
