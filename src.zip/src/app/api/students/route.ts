import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, requireSession, jsonError } from "@/lib/permissions";
import { logAudit } from "@/lib/audit";
import { Gender } from "@prisma/client";

export async function GET(req: NextRequest) {
  try {
    const session = await requireSession();
    const { searchParams } = new URL(req.url);
    const schoolId = searchParams.get("schoolId") || undefined;
    const classId = searchParams.get("classId") || undefined;
    const query = searchParams.get("q")?.trim();

    const students = await prisma.student.findMany({
      where: {
        classId,
        class: schoolId ? { schoolId } : undefined,
        ...(query
          ? {
              OR: [
                { name: { contains: query, mode: "insensitive" } },
                { rollNumber: { contains: query, mode: "insensitive" } },
                { admissionNumber: { contains: query, mode: "insensitive" } },
              ],
            }
          : {}),
      },
      orderBy: [{ class: { grade: "asc" } }, { class: { section: "asc" } }, { rollNumber: "asc" }],
      include: {
        class: { include: { school: true } },
        generalExam: { select: { status: true } },
        ent: { select: { status: true } },
        vision: { select: { status: true } },
        dental: { select: { status: true } },
      },
      take: 500,
    });

    // Doctors only need to reason about their own assigned section(s) in the
    // list view — everything else stays hidden from the payload.
    if (session.user.role === "DOCTOR") {
      const scoped = students.map((s) => ({
        id: s.id,
        name: s.name,
        rollNumber: s.rollNumber,
        admissionNumber: s.admissionNumber,
        class: { grade: s.class.grade, section: s.class.section, schoolName: s.class.school.name },
        mySections: session.user.sections.map((sec) => ({
          section: sec,
          status:
            sec === "GENERAL_EXAM"
              ? s.generalExam?.status ?? "PENDING"
              : sec === "ENT"
              ? s.ent?.status ?? "PENDING"
              : sec === "VISION"
              ? s.vision?.status ?? "PENDING"
              : s.dental?.status ?? "PENDING",
        })),
      }));
      return NextResponse.json({ students: scoped });
    }

    return NextResponse.json({ students });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

const createSchema = z.object({
  classId: z.string().min(1),
  name: z.string().trim().min(1, "Name is required"),
  rollNumber: z.string().trim().min(1, "Roll number is required"),
  admissionNumber: z.string().trim().min(1, "Admission number is required"),
  parentage: z.string().trim().min(1, "Parent/guardian name is required"),
  gender: z.nativeEnum(Gender),
  mobileNumber: z.string().trim().min(1, "Mobile number is required"),
});

export async function POST(req: NextRequest) {
  try {
    const session = await requireAdmin();
    const data = createSchema.parse(await req.json());
    const student = await prisma.student.create({ data });
    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "STUDENT_CREATE",
      studentId: student.id,
      detail: { name: student.name, rollNumber: student.rollNumber },
    });
    return NextResponse.json({ student }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    if (error && typeof error === "object" && "code" in error && error.code === "P2002") {
      return NextResponse.json({ error: "A student with that roll number already exists in this class" }, { status: 409 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
