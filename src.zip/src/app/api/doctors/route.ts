import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";
import { logAudit } from "@/lib/audit";
import { SectionType } from "@prisma/client";

export async function GET() {
  try {
    await requireAdmin();
    const doctors = await prisma.user.findMany({
      where: { role: "DOCTOR" },
      orderBy: { name: "asc" },
      include: { sections: true },
    });
    return NextResponse.json({
      doctors: doctors.map((d) => ({
        id: d.id,
        username: d.username,
        name: d.name,
        isActive: d.isActive,
        sections: d.sections.map((s) => s.section),
        createdAt: d.createdAt,
      })),
    });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

const createSchema = z.object({
  username: z.string().trim().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().trim().min(1, "Name is required"),
  sections: z.array(z.nativeEnum(SectionType)).min(1, "Assign at least one section"),
});

export async function POST(req: NextRequest) {
  try {
    const session = await requireAdmin();
    const data = createSchema.parse(await req.json());
    const username = data.username.toLowerCase();

    const existing = await prisma.user.findUnique({ where: { username } });
    if (existing) return NextResponse.json({ error: "That username is already taken" }, { status: 409 });

    const passwordHash = await bcrypt.hash(data.password, 12);
    const doctor = await prisma.user.create({
      data: {
        username,
        passwordHash,
        name: data.name,
        role: "DOCTOR",
        sections: { create: data.sections.map((section) => ({ section })) },
      },
      include: { sections: true },
    });

    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "DOCTOR_CREATE",
      detail: { username: doctor.username, sections: data.sections },
    });

    return NextResponse.json({ doctor: { ...doctor, passwordHash: undefined } }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
