import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";
import { logAudit } from "@/lib/audit";
import { SectionType } from "@prisma/client";

type Ctx = { params: Promise<{ doctorId: string }> };

const updateSchema = z.object({
  name: z.string().trim().min(1).optional(),
  isActive: z.boolean().optional(),
  sections: z.array(z.nativeEnum(SectionType)).min(1).optional(),
});

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try {
    const session = await requireAdmin();
    const { doctorId } = await params;
    const data = updateSchema.parse(await req.json());

    if (data.sections) {
      await prisma.doctorSection.deleteMany({ where: { doctorId } });
    }

    const doctor = await prisma.user.update({
      where: { id: doctorId },
      data: {
        name: data.name,
        isActive: data.isActive,
        sections: data.sections ? { create: data.sections.map((section) => ({ section })) } : undefined,
      },
      include: { sections: true },
    });

    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "DOCTOR_UPDATE",
      detail: { doctorUsername: doctor.username, ...data },
    });

    return NextResponse.json({ doctor: { ...doctor, passwordHash: undefined } });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  try {
    const session = await requireAdmin();
    const { doctorId } = await params;
    const doctor = await prisma.user.findUnique({ where: { id: doctorId } });
    await prisma.user.delete({ where: { id: doctorId } });
    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "DOCTOR_DELETE",
      detail: { username: doctor?.username },
    });
    return NextResponse.json({ ok: true });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
