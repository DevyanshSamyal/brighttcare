import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";
import { logAudit } from "@/lib/audit";

const schema = z.object({ password: z.string().min(6, "Password must be at least 6 characters") });

// Password reset is deliberately admin-only, with no self-service "forgot
// password" flow — there's no email system to deliver a reset link through.
export async function POST(req: NextRequest, { params }: { params: Promise<{ doctorId: string }> }) {
  try {
    const session = await requireAdmin();
    const { doctorId } = await params;
    const { password } = schema.parse(await req.json());
    const passwordHash = await bcrypt.hash(password, 12);
    const doctor = await prisma.user.update({
      where: { id: doctorId },
      data: { passwordHash },
    });
    await logAudit({
      userId: session.user.id,
      userName: session.user.name,
      action: "DOCTOR_PASSWORD_RESET",
      detail: { username: doctor.username },
    });
    return NextResponse.json({ ok: true });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
