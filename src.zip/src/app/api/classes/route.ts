import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";

const createSchema = z.object({
  schoolId: z.string().min(1),
  grade: z.string().trim().min(1, "Grade / class is required"),
  section: z.string().trim().min(1, "Section / division is required"),
});

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
    const data = createSchema.parse(await req.json());
    const schoolClass = await prisma.schoolClass.create({ data });
    return NextResponse.json({ schoolClass }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    // Unique constraint violation on (schoolId, grade, section)
    if (error && typeof error === "object" && "code" in error && error.code === "P2002") {
      return NextResponse.json({ error: "That class/section already exists for this school" }, { status: 409 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
