import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";

type Ctx = { params: Promise<{ classId: string }> };

export async function GET(_req: NextRequest, { params }: Ctx) {
  try {
    await requireAdmin();
    const { classId } = await params;
    const schoolClass = await prisma.schoolClass.findUnique({
      where: { id: classId },
      include: {
        school: true,
        students: {
          orderBy: { rollNumber: "asc" },
          include: {
            generalExam: { select: { status: true } },
            ent: { select: { status: true } },
            vision: { select: { status: true } },
            dental: { select: { status: true } },
          },
        },
      },
    });
    if (!schoolClass) return NextResponse.json({ error: "Class not found" }, { status: 404 });
    return NextResponse.json({ schoolClass });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  try {
    await requireAdmin();
    const { classId } = await params;
    await prisma.schoolClass.delete({ where: { id: classId } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
