import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";
import { SECTION_ORDER } from "@/lib/sections";
import { sectionStatus } from "@/lib/sectionRecords";

export async function GET() {
  try {
    await requireAdmin();

    const students = await prisma.student.findMany({
      include: {
        class: { include: { school: true } },
        generalExam: { select: { status: true } },
        ent: { select: { status: true } },
        vision: { select: { status: true } },
        dental: { select: { status: true } },
      },
    });

    const totalStudents = students.length;
    const perSection = Object.fromEntries(
      SECTION_ORDER.map((section) => {
        const done = students.filter((s) => {
          const st = sectionStatus(section, s);
          return st === "COMPLETE" || st === "ABSENT";
        }).length;
        return [section, { done, total: totalStudents, pct: totalStudents ? Math.round((done / totalStudents) * 100) : 0 }];
      })
    );

    const readyForPdf = students.filter((s) =>
      SECTION_ORDER.every((section) => {
        const st = sectionStatus(section, s);
        return st === "COMPLETE" || st === "ABSENT";
      })
    );

    const pdfGenerated = students.filter((s) => s.pdfGeneratedAt).length;

    const pendingStudents = students
      .filter((s) => !SECTION_ORDER.every((section) => sectionStatus(section, s) !== "PENDING"))
      .slice(0, 25)
      .map((s) => ({
        id: s.id,
        name: s.name,
        rollNumber: s.rollNumber,
        class: `${s.class.grade}-${s.class.section}`,
        school: s.class.school.name,
        pendingSections: SECTION_ORDER.filter((section) => sectionStatus(section, s) === "PENDING"),
      }));

    const totalSchools = await prisma.school.count();
    const totalClasses = await prisma.schoolClass.count();
    const totalDoctors = await prisma.user.count({ where: { role: "DOCTOR", isActive: true } });

    return NextResponse.json({
      totalStudents,
      totalSchools,
      totalClasses,
      totalDoctors,
      perSection,
      readyForPdfCount: readyForPdf.length,
      pdfGeneratedCount: pdfGenerated,
      pendingStudents,
    });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
