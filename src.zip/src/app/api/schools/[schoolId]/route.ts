import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";

type Ctx = { params: Promise<{ schoolId: string }> };

export async function GET(_req: NextRequest, { params }: Ctx) {
  try {
    await requireAdmin();
    const { schoolId } = await params;
    const school = await prisma.school.findUnique({
      where: { id: schoolId },
      include: {
        classes: {
          orderBy: [{ grade: "asc" }, { section: "asc" }],
          include: { _count: { select: { students: true } } },
        },
      },
    });
    if (!school) return NextResponse.json({ error: "School not found" }, { status: 404 });
    return NextResponse.json({ school });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

const updateSchema = z.object({ name: z.string().trim().min(1) });

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try {
    await requireAdmin();
    const { schoolId } = await params;
    const data = updateSchema.parse(await req.json());
    const school = await prisma.school.update({ where: { id: schoolId }, data });
    return NextResponse.json({ school });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  try {
    await requireAdmin();
    const { schoolId } = await params;
    await prisma.school.delete({ where: { id: schoolId } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
