import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, jsonError } from "@/lib/permissions";

export async function GET() {
  try {
    await requireAdmin();
    const schools = await prisma.school.findMany({
      orderBy: { name: "asc" },
      include: {
        classes: {
          orderBy: [{ grade: "asc" }, { section: "asc" }],
          include: { _count: { select: { students: true } } },
        },
      },
    });
    return NextResponse.json({ schools });
  } catch (error) {
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}

const createSchema = z.object({ name: z.string().trim().min(1, "School name is required") });

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
    const data = createSchema.parse(await req.json());
    const school = await prisma.school.create({ data });
    return NextResponse.json({ school }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    const { body, status } = jsonError(error);
    return NextResponse.json(body, { status });
  }
}
