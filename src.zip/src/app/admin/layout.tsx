import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { TopNav } from "@/components/TopNav";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "ADMIN") redirect("/login");

  return (
    <div className="min-h-screen bg-paper">
      <TopNav name={session.user.name} roleLabel="Admin" />
      <nav className="bg-card border-b border-mist">
        <div className="max-w-5xl mx-auto px-4 flex gap-1 overflow-x-auto">
          {[
            { href: "/admin/dashboard", label: "Dashboard" },
            { href: "/admin/schools", label: "Schools" },
            { href: "/admin/doctors", label: "Doctors" },
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="px-3 py-2.5 text-sm font-medium text-ink-soft hover:text-pine border-b-2 border-transparent hover:border-pine transition-colors whitespace-nowrap"
            >
              {item.label}
            </Link>
          ))}
        </div>
      </nav>
      <main className="max-w-5xl mx-auto px-4 py-6">{children}</main>
    </div>
  );
}
