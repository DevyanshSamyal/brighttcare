"use client";

import { use, useEffect, useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { SECTION_ORDER, SECTIONS } from "@/lib/sections";
import { SectionStatusPill } from "@/components/SectionStamp";
import type { SectionStatus, SectionType } from "@prisma/client";

interface StudentDetail {
  id: string;
  name: string;
  rollNumber: string;
  admissionNumber: string;
  parentage: string;
  gender: "MALE" | "FEMALE" | "OTHER";
  mobileNumber: string;
  examinationDate: string | null;
  medicalOfficerName: string | null;
  pdfGeneratedAt: string | null;
  class: { grade: string; section: string; school: { id: string; name: string } };
  generalExam: { status: SectionStatus } | null;
  ent: { status: SectionStatus } | null;
  vision: { status: SectionStatus } | null;
  dental: { status: SectionStatus } | null;
}

function statusFor(student: StudentDetail, section: SectionType): SectionStatus {
  const map = { GENERAL_EXAM: student.generalExam, ENT: student.ent, VISION: student.vision, DENTAL: student.dental };
  return map[section]?.status ?? "PENDING";
}

export default function AdminStudentDetailPage({ params }: { params: Promise<{ studentId: string }> }) {
  const { studentId } = use(params);
  const router = useRouter();
  const [student, setStudent] = useState<StudentDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [masterForm, setMasterForm] = useState<Record<string, string>>({});
  const [examForm, setExamForm] = useState({ examinationDate: "", medicalOfficerName: "" });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [generatingPdf, setGeneratingPdf] = useState(false);

  function load() {
    setLoading(true);
    fetch(`/api/students/${studentId}`)
      .then((r) => r.json())
      .then((data) => {
        const s: StudentDetail = data.student;
        setStudent(s);
        if (s) {
          setMasterForm({
            name: s.name,
            rollNumber: s.rollNumber,
            admissionNumber: s.admissionNumber,
            parentage: s.parentage,
            gender: s.gender,
            mobileNumber: s.mobileNumber,
          });
          setExamForm({
            examinationDate: s.examinationDate ? s.examinationDate.slice(0, 10) : "",
            medicalOfficerName: s.medicalOfficerName ?? "",
          });
        }
      })
      .finally(() => setLoading(false));
  }

  useEffect(load, [studentId]);

  async function saveMaster(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    const res = await fetch(`/api/students/${studentId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(masterForm),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) {
      setMessage({ type: "err", text: data.error });
      return;
    }
    setMessage({ type: "ok", text: "Student details saved." });
    load();
  }

  async function saveExam(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    const res = await fetch(`/api/students/${studentId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        examinationDate: examForm.examinationDate ? new Date(examForm.examinationDate).toISOString() : null,
        medicalOfficerName: examForm.medicalOfficerName || null,
      }),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) {
      setMessage({ type: "err", text: data.error });
      return;
    }
    setMessage({ type: "ok", text: "Examination details saved." });
    load();
  }

  async function generatePdf() {
    setGeneratingPdf(true);
    setPdfError(null);
    const res = await fetch(`/api/students/${studentId}/pdf`);
    if (!res.ok) {
      const data = await res.json();
      setPdfError(data.error || "Couldn't generate the PDF.");
      setGeneratingPdf(false);
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
    setGeneratingPdf(false);
    load();
  }

  async function deleteStudent() {
    if (!student || !confirm(`Permanently delete ${student.name}'s record, including all section data? This can't be undone.`)) return;
    const schoolId = student.class.school.id;
    const res = await fetch(`/api/students/${studentId}`, { method: "DELETE" });
    if (res.ok) router.push(`/admin/schools/${schoolId}`);
  }

  if (loading) return <p className="text-sm text-ink-soft py-8 text-center">Loading…</p>;
  if (!student) return <p className="text-sm text-rose py-8 text-center">Student not found.</p>;

  const allResolved = SECTION_ORDER.every((s) => statusFor(student, s) !== "PENDING");
  const examDetailsSet = !!student.examinationDate && !!student.medicalOfficerName;
  const canGeneratePdf = allResolved && examDetailsSet;

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      <div>
        <Link href={`/admin/schools/${student.class.school.id}`} className="text-sm text-ink-soft hover:text-pine">
          ← {student.class.school.name}
        </Link>
        <h1 className="font-display text-2xl font-semibold text-ink mt-1">{student.name}</h1>
        <p className="text-sm text-ink-soft font-mono">
          Class {student.class.grade}-{student.class.section} · Roll {student.rollNumber} · Admission {student.admissionNumber}
        </p>
      </div>

      {message && (
        <p className={`text-sm rounded-md px-3 py-2 ${message.type === "ok" ? "bg-pine-light text-pine" : "bg-rose-light text-rose"}`}>
          {message.text}
        </p>
      )}

      <section className="card p-4">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-pine mb-3">Student Details</h2>
        <form onSubmit={saveMaster} className="grid sm:grid-cols-2 gap-4">
          <Field label="Name" value={masterForm.name} onChange={(v) => setMasterForm({ ...masterForm, name: v })} />
          <Field label="Roll Number" value={masterForm.rollNumber} onChange={(v) => setMasterForm({ ...masterForm, rollNumber: v })} mono />
          <Field
            label="Admission Number"
            value={masterForm.admissionNumber}
            onChange={(v) => setMasterForm({ ...masterForm, admissionNumber: v })}
            mono
          />
          <Field label="Parent / Guardian" value={masterForm.parentage} onChange={(v) => setMasterForm({ ...masterForm, parentage: v })} />
          <div>
            <label className="field-label">Gender</label>
            <select
              className="field-input"
              value={masterForm.gender}
              onChange={(e) => setMasterForm({ ...masterForm, gender: e.target.value })}
            >
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <Field label="Mobile Number" value={masterForm.mobileNumber} onChange={(v) => setMasterForm({ ...masterForm, mobileNumber: v })} mono />
          <div className="sm:col-span-2">
            <button className="btn-primary" disabled={saving}>
              Save Details
            </button>
          </div>
        </form>
      </section>

      <section className="card p-4">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-pine mb-3">Examination Details (for the PDF)</h2>
        <form onSubmit={saveExam} className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="field-label">Examination Date</label>
            <input
              type="date"
              className="field-input"
              value={examForm.examinationDate}
              onChange={(e) => setExamForm({ ...examForm, examinationDate: e.target.value })}
            />
          </div>
          <Field
            label="Medical Officer Name"
            value={examForm.medicalOfficerName}
            onChange={(v) => setExamForm({ ...examForm, medicalOfficerName: v })}
          />
          <div className="sm:col-span-2">
            <button className="btn-primary" disabled={saving}>
              Save
            </button>
          </div>
        </form>
      </section>

      <section className="card p-4">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-pine mb-3">Sections</h2>
        <div className="divide-y divide-mist">
          {SECTION_ORDER.map((section) => (
            <div key={section} className="flex items-center justify-between py-2.5">
              <span className="text-sm text-ink">{SECTIONS[section].label}</span>
              <div className="flex items-center gap-3">
                <SectionStatusPill status={statusFor(student, section)} />
                <Link href={`/admin/students/${student.id}/${section}`} className="text-xs text-pine hover:underline">
                  View / Edit
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="card p-4">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-pine mb-3">Final PDF</h2>
        {!allResolved && <p className="text-sm text-ink-soft mb-3">Waiting on: sections not yet complete or marked absent.</p>}
        {allResolved && !examDetailsSet && (
          <p className="text-sm text-ink-soft mb-3">Set the examination date and medical officer name above first.</p>
        )}
        {student.pdfGeneratedAt && (
          <p className="text-xs text-ink-soft mb-3">Last generated {new Date(student.pdfGeneratedAt).toLocaleString("en-IN")}.</p>
        )}
        {pdfError && <p className="text-sm text-rose mb-3">{pdfError}</p>}
        <button className="btn-primary" disabled={!canGeneratePdf || generatingPdf} onClick={generatePdf}>
          {generatingPdf ? "Generating…" : student.pdfGeneratedAt ? "Regenerate & View PDF" : "Generate PDF"}
        </button>
      </section>

      <section className="card p-4 border-rose/20">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-rose mb-3">Danger Zone</h2>
        <button onClick={deleteStudent} className="btn-danger">
          Delete Student Record
        </button>
      </section>
    </div>
  );
}

function Field({ label, value, onChange, mono }: { label: string; value: string; onChange: (v: string) => void; mono?: boolean }) {
  return (
    <div>
      <label className="field-label">{label}</label>
      <input className={`field-input ${mono ? "font-mono" : ""}`} value={value ?? ""} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
