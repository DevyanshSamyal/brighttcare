"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { SECTIONS, SECTION_ORDER } from "@/lib/sections";
import type { SectionType } from "@prisma/client";

interface DashboardData {
  totalStudents: number;
  totalSchools: number;
  totalClasses: number;
  totalDoctors: number;
  perSection: Record<SectionType, { done: number; total: number; pct: number }>;
  readyForPdfCount: number;
  pdfGeneratedCount: number;
  pendingStudents: {
    id: string;
    name: string;
    rollNumber: string;
    class: string;
    school: string;
    pendingSections: SectionType[];
  }[];
}

export default function AdminDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);

  useEffect(() => {
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then(setData);
  }, []);

  if (!data) return <p className="text-sm text-ink-soft py-8 text-center">Loading…</p>;

  const stats = [
    { label: "Students", value: data.totalStudents },
    { label: "Schools", value: data.totalSchools },
    { label: "Classes", value: data.totalClasses },
    { label: "Active Doctors", value: data.totalDoctors },
    { label: "Ready for PDF", value: data.readyForPdfCount },
    { label: "PDFs Generated", value: data.pdfGeneratedCount },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink mb-4">Dashboard</h1>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {stats.map((s) => (
            <div key={s.label} className="card p-3">
              <p className="font-display text-2xl font-semibold text-pine">{s.value}</p>
              <p className="text-xs text-ink-soft mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-sm font-semibold text-ink mb-3">Completion by section</h2>
        <div className="card p-4 space-y-3">
          {SECTION_ORDER.map((section) => {
            const s = data.perSection[section];
            return (
              <div key={section}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium text-ink">{SECTIONS[section].label}</span>
                  <span className="text-ink-soft">
                    {s.done}/{s.total} ({s.pct}%)
                  </span>
                </div>
                <div className="h-2 rounded-full bg-mist overflow-hidden">
                  <div className="h-full bg-pine rounded-full transition-all" style={{ width: `${s.pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <h2 className="text-sm font-semibold text-ink mb-3">Students with pending sections</h2>
        {data.pendingStudents.length === 0 ? (
          <p className="text-sm text-ink-soft">Nothing pending — every student has moved past every section.</p>
        ) : (
          <div className="card divide-y divide-mist">
            {data.pendingStudents.map((s) => (
              <Link
                key={s.id}
                href={`/admin/students/${s.id}`}
                className="flex items-center justify-between gap-4 px-4 py-3 hover:bg-mist/40 transition-colors"
              >
                <div className="min-w-0">
                  <p className="text-sm font-medium text-ink truncate">{s.name}</p>
                  <p className="text-xs text-ink-soft font-mono truncate">
                    Roll {s.rollNumber} · {s.class} · {s.school}
                  </p>
                </div>
                <div className="flex gap-1 flex-wrap justify-end shrink-0 max-w-[50%]">
                  {s.pendingSections.map((sec) => (
                    <span key={sec} className="text-[11px] bg-amber-light text-amber rounded-full px-2 py-0.5">
                      {SECTIONS[sec].shortLabel}
                    </span>
                  ))}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
