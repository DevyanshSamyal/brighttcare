"use client";

import { use, useEffect, useState, FormEvent } from "react";
import Link from "next/link";
import { SECTION_ORDER, SECTIONS } from "@/lib/sections";
import { SectionStamp } from "@/components/SectionStamp";
import type { SectionStatus, SectionType } from "@prisma/client";

interface StudentRow {
  id: string;
  name: string;
  rollNumber: string;
  admissionNumber: string;
  generalExam: { status: SectionStatus } | null;
  ent: { status: SectionStatus } | null;
  vision: { status: SectionStatus } | null;
  dental: { status: SectionStatus } | null;
}

interface ClassDetail {
  id: string;
  grade: string;
  section: string;
  school: { id: string; name: string };
  students: StudentRow[];
}

const emptyForm = { name: "", rollNumber: "", admissionNumber: "", parentage: "", gender: "MALE", mobileNumber: "" };

function statusFor(student: StudentRow, section: SectionType): SectionStatus {
  const map = { GENERAL_EXAM: student.generalExam, ENT: student.ent, VISION: student.vision, DENTAL: student.dental };
  return map[section]?.status ?? "PENDING";
}

export default function ClassDetailPage({ params }: { params: Promise<{ classId: string }> }) {
  const { classId } = use(params);
  const [cls, setCls] = useState<ClassDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function load() {
    setLoading(true);
    fetch(`/api/classes/${classId}`)
      .then((r) => r.json())
      .then((data) => setCls(data.schoolClass ?? null))
      .finally(() => setLoading(false));
  }

  useEffect(load, [classId]);

  async function createStudent(e: FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError(null);
    const res = await fetch("/api/students", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ classId, ...form }),
    });
    const data = await res.json();
    setCreating(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setForm(emptyForm);
    setShowForm(false);
    load();
  }

  if (loading) return <p className="text-sm text-ink-soft py-8 text-center">Loading…</p>;
  if (!cls) return <p className="text-sm text-rose py-8 text-center">Class not found.</p>;

  return (
    <div className="space-y-6">
      <div>
        <Link href={`/admin/schools/${cls.school.id}`} className="text-sm text-ink-soft hover:text-pine">
          ← {cls.school.name}
        </Link>
        <h1 className="font-display text-2xl font-semibold text-ink mt-1">
          {cls.grade}-{cls.section}
        </h1>
      </div>

      <button onClick={() => setShowForm((v) => !v)} className="btn-primary">
        {showForm ? "Cancel" : "+ Add Student"}
      </button>

      {showForm && (
        <form onSubmit={createStudent} className="card p-4 grid sm:grid-cols-2 gap-4">
          <div>
            <label className="field-label">Name *</label>
            <input className="field-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div>
            <label className="field-label">Roll Number *</label>
            <input
              className="field-input font-mono"
              value={form.rollNumber}
              onChange={(e) => setForm({ ...form, rollNumber: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="field-label">Admission Number *</label>
            <input
              className="field-input font-mono"
              value={form.admissionNumber}
              onChange={(e) => setForm({ ...form, admissionNumber: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="field-label">Parent / Guardian Name *</label>
            <input
              className="field-input"
              value={form.parentage}
              onChange={(e) => setForm({ ...form, parentage: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="field-label">Gender *</label>
            <select className="field-input" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div>
            <label className="field-label">Mobile Number *</label>
            <input
              className="field-input font-mono"
              value={form.mobileNumber}
              onChange={(e) => setForm({ ...form, mobileNumber: e.target.value })}
              required
            />
          </div>
          {error && <p className="text-sm text-rose sm:col-span-2">{error}</p>}
          <div className="sm:col-span-2">
            <button className="btn-primary" disabled={creating}>
              {creating ? "Adding…" : "Add Student"}
            </button>
          </div>
        </form>
      )}

      {cls.students.length === 0 ? (
        <p className="text-sm text-ink-soft py-8 text-center">No students in this class yet.</p>
      ) : (
        <div className="card divide-y divide-mist">
          {cls.students.map((s) => (
            <Link
              key={s.id}
              href={`/admin/students/${s.id}`}
              className="flex items-center justify-between gap-4 px-4 py-3 hover:bg-mist/40 transition-colors"
            >
              <div className="min-w-0">
                <p className="text-sm font-medium text-ink truncate">{s.name}</p>
                <p className="text-xs text-ink-soft font-mono">Roll {s.rollNumber}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {SECTION_ORDER.map((section) => (
                  <div key={section} title={SECTIONS[section].label}>
                    <SectionStamp status={statusFor(s, section)} size={18} />
                  </div>
                ))}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
