"use client";

import { useEffect, useState, FormEvent } from "react";
import { SECTION_ORDER, SECTIONS } from "@/lib/sections";
import type { SectionType } from "@prisma/client";

interface Doctor {
  id: string;
  username: string;
  name: string;
  isActive: boolean;
  sections: SectionType[];
}

const emptyForm = { username: "", password: "", name: "", sections: [] as SectionType[] };

export default function DoctorsPage() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  function load() {
    setLoading(true);
    fetch("/api/doctors")
      .then((r) => r.json())
      .then((data) => setDoctors(data.doctors ?? []))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  function toggleSection(list: SectionType[], section: SectionType): SectionType[] {
    return list.includes(section) ? list.filter((s) => s !== section) : [...list, section];
  }

  async function createDoctor(e: FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError(null);
    const res = await fetch("/api/doctors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setCreating(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setForm(emptyForm);
    setShowForm(false);
    load();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink mb-4">Doctor Accounts</h1>
        <button onClick={() => setShowForm((v) => !v)} className="btn-primary">
          {showForm ? "Cancel" : "+ Add Doctor"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={createDoctor} className="card p-4 grid sm:grid-cols-2 gap-4">
          <div>
            <label className="field-label">Full Name *</label>
            <input className="field-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div>
            <label className="field-label">Username *</label>
            <input
              className="field-input font-mono"
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
              required
            />
          </div>
          <div className="sm:col-span-2">
            <label className="field-label">Temporary Password *</label>
            <input
              type="text"
              className="field-input font-mono max-w-xs"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              minLength={6}
              required
            />
          </div>
          <div className="sm:col-span-2">
            <label className="field-label">Assigned Section(s) *</label>
            <div className="flex flex-wrap gap-3 mt-1">
              {SECTION_ORDER.map((section) => (
                <label key={section} className="flex items-center gap-1.5 text-sm text-ink">
                  <input
                    type="checkbox"
                    checked={form.sections.includes(section)}
                    onChange={() => setForm({ ...form, sections: toggleSection(form.sections, section) })}
                  />
                  {SECTIONS[section].label}
                </label>
              ))}
            </div>
          </div>
          {error && <p className="text-sm text-rose sm:col-span-2">{error}</p>}
          <div className="sm:col-span-2">
            <button className="btn-primary" disabled={creating}>
              {creating ? "Creating…" : "Create Doctor Account"}
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-sm text-ink-soft py-8 text-center">Loading…</p>
      ) : doctors.length === 0 ? (
        <p className="text-sm text-ink-soft py-8 text-center">No doctor accounts yet — add one above.</p>
      ) : (
        <div className="card divide-y divide-mist">
          {doctors.map((d) => (
            <DoctorRow
              key={d.id}
              doctor={d}
              expanded={expanded === d.id}
              onToggleExpand={() => setExpanded(expanded === d.id ? null : d.id)}
              onChanged={load}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function DoctorRow({
  doctor,
  expanded,
  onToggleExpand,
  onChanged,
}: {
  doctor: Doctor;
  expanded: boolean;
  onToggleExpand: () => void;
  onChanged: () => void;
}) {
  const [sections, setSections] = useState<SectionType[]>(doctor.sections);
  const [newPassword, setNewPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);

  function toggleSection(section: SectionType) {
    setSections((prev) => (prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]));
  }

  async function saveSections() {
    setBusy(true);
    setNote(null);
    const res = await fetch(`/api/doctors/${doctor.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sections }),
    });
    setBusy(false);
    setNote(res.ok ? "Sections updated." : "Couldn't save — pick at least one section.");
    if (res.ok) onChanged();
  }

  async function toggleActive() {
    setBusy(true);
    await fetch(`/api/doctors/${doctor.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !doctor.isActive }),
    });
    setBusy(false);
    onChanged();
  }

  async function resetPassword() {
    if (newPassword.length < 6) {
      setNote("Password must be at least 6 characters.");
      return;
    }
    setBusy(true);
    setNote(null);
    const res = await fetch(`/api/doctors/${doctor.id}/password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: newPassword }),
    });
    setBusy(false);
    setNote(res.ok ? "Password reset." : "Couldn't reset password.");
    if (res.ok) setNewPassword("");
  }

  async function removeDoctor() {
    if (!confirm(`Remove ${doctor.name}'s account? They'll immediately lose access.`)) return;
    await fetch(`/api/doctors/${doctor.id}`, { method: "DELETE" });
    onChanged();
  }

  return (
    <div className="px-4 py-3">
      <button onClick={onToggleExpand} className="w-full flex items-center justify-between gap-4 text-left">
        <div className="min-w-0">
          <p className="text-sm font-medium text-ink">
            {doctor.name} <span className="text-ink-soft font-mono text-xs">@{doctor.username}</span>
            {!doctor.isActive && <span className="ml-2 text-[11px] bg-mist text-ink-soft rounded-full px-2 py-0.5">Inactive</span>}
          </p>
          <p className="text-xs text-ink-soft mt-0.5">
            {doctor.sections.length ? doctor.sections.map((s) => SECTIONS[s].shortLabel).join(", ") : "No section assigned"}
          </p>
        </div>
        <span className="text-xs text-pine shrink-0">{expanded ? "Close" : "Manage"}</span>
      </button>

      {expanded && (
        <div className="mt-3 pt-3 border-t border-mist space-y-4">
          <div>
            <label className="field-label">Assigned Section(s)</label>
            <div className="flex flex-wrap gap-3">
              {SECTION_ORDER.map((section) => (
                <label key={section} className="flex items-center gap-1.5 text-sm text-ink">
                  <input type="checkbox" checked={sections.includes(section)} onChange={() => toggleSection(section)} />
                  {SECTIONS[section].label}
                </label>
              ))}
            </div>
            <button onClick={saveSections} disabled={busy} className="btn-secondary mt-2 !py-1.5 !px-3 text-xs">
              Save Sections
            </button>
          </div>

          <div>
            <label className="field-label">Reset Password</label>
            <div className="flex gap-2">
              <input
                type="text"
                className="field-input font-mono max-w-[200px]"
                placeholder="New password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
              <button onClick={resetPassword} disabled={busy} className="btn-secondary !py-1.5 !px-3 text-xs">
                Reset
              </button>
            </div>
          </div>

          {note && <p className="text-xs text-ink-soft">{note}</p>}

          <div className="flex gap-2">
            <button onClick={toggleActive} disabled={busy} className="btn-secondary !py-1.5 !px-3 text-xs">
              {doctor.isActive ? "Deactivate" : "Reactivate"}
            </button>
            <button onClick={removeDoctor} className="btn-danger !py-1.5 !px-3 text-xs">
              Remove Account
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
