"use client";

import { use, useEffect, useState, FormEvent } from "react";
import Link from "next/link";

interface SchoolDetail {
  id: string;
  name: string;
  classes: { id: string; grade: string; section: string; _count: { students: number } }[];
}

export default function SchoolDetailPage({ params }: { params: Promise<{ schoolId: string }> }) {
  const { schoolId } = use(params);
  const [school, setSchool] = useState<SchoolDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [grade, setGrade] = useState("");
  const [section, setSection] = useState("");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function load() {
    setLoading(true);
    fetch(`/api/schools/${schoolId}`)
      .then((r) => r.json())
      .then((data) => setSchool(data.school ?? null))
      .finally(() => setLoading(false));
  }

  useEffect(load, [schoolId]);

  async function createClass(e: FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError(null);
    const res = await fetch("/api/classes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ schoolId, grade, section }),
    });
    const data = await res.json();
    setCreating(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setGrade("");
    setSection("");
    load();
  }

  if (loading) return <p className="text-sm text-ink-soft py-8 text-center">Loading…</p>;
  if (!school) return <p className="text-sm text-rose py-8 text-center">School not found.</p>;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/admin/schools" className="text-sm text-ink-soft hover:text-pine">
          ← Schools
        </Link>
        <h1 className="font-display text-2xl font-semibold text-ink mt-1">{school.name}</h1>
      </div>

      <form onSubmit={createClass} className="card p-4 flex flex-wrap items-end gap-3">
        <div>
          <label className="field-label">Grade / Class</label>
          <input className="field-input w-28" placeholder="e.g. 8" value={grade} onChange={(e) => setGrade(e.target.value)} required />
        </div>
        <div>
          <label className="field-label">Section / Division</label>
          <input className="field-input w-28" placeholder="e.g. A" value={section} onChange={(e) => setSection(e.target.value)} required />
        </div>
        <button className="btn-primary" disabled={creating}>
          {creating ? "Adding…" : "Add Class"}
        </button>
        {error && <p className="text-sm text-rose w-full">{error}</p>}
      </form>

      {school.classes.length === 0 ? (
        <p className="text-sm text-ink-soft py-8 text-center">No classes yet — add one above.</p>
      ) : (
        <div className="grid sm:grid-cols-3 gap-3">
          {school.classes.map((c) => (
            <Link key={c.id} href={`/admin/classes/${c.id}`} className="card p-4 hover:shadow-raised transition-shadow">
              <p className="font-display text-lg text-ink">
                {c.grade}-{c.section}
              </p>
              <p className="text-xs text-ink-soft mt-1">
                {c._count.students} {c._count.students === 1 ? "student" : "students"}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
