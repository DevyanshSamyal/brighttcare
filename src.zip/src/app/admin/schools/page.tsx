"use client";

import { useEffect, useState, FormEvent } from "react";
import Link from "next/link";

interface SchoolRow {
  id: string;
  name: string;
  classes: { id: string; grade: string; section: string; _count: { students: number } }[];
}

export default function SchoolsPage() {
  const [schools, setSchools] = useState<SchoolRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function load() {
    setLoading(true);
    fetch("/api/schools")
      .then((r) => r.json())
      .then((data) => setSchools(data.schools ?? []))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function createSchool(e: FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError(null);
    const res = await fetch("/api/schools", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    const data = await res.json();
    setCreating(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setName("");
    load();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink mb-4">Schools</h1>
        <form onSubmit={createSchool} className="flex gap-2 max-w-md">
          <input
            className="field-input"
            placeholder="New school name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <button className="btn-primary shrink-0" disabled={creating}>
            {creating ? "Adding…" : "Add School"}
          </button>
        </form>
        {error && <p className="text-sm text-rose mt-2">{error}</p>}
      </div>

      {loading ? (
        <p className="text-sm text-ink-soft py-8 text-center">Loading…</p>
      ) : schools.length === 0 ? (
        <p className="text-sm text-ink-soft py-8 text-center">No schools yet — add one above to get started.</p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3">
          {schools.map((school) => {
            const studentCount = school.classes.reduce((sum, c) => sum + c._count.students, 0);
            return (
              <Link key={school.id} href={`/admin/schools/${school.id}`} className="card p-4 hover:shadow-raised transition-shadow">
                <p className="font-display text-lg text-ink">{school.name}</p>
                <p className="text-xs text-ink-soft mt-1">
                  {school.classes.length} {school.classes.length === 1 ? "class" : "classes"} · {studentCount}{" "}
                  {studentCount === 1 ? "student" : "students"}
                </p>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
