export type BmiCategory = "Underweight" | "Normal" | "Overweight" | "Obese";

export interface BmiResult {
  value: number; // kg/m^2, rounded to 1 decimal
  category: BmiCategory;
}

/**
 * Auto-calculated from height/weight — never stored, so it can't drift out
 * of sync with the inputs. Bands confirmed: Underweight <18.5, Normal
 * 18.5-24.9, Overweight 25-29.9, Obese >=30.
 */
export function calculateBmi(heightCm: number | null | undefined, weightKg: number | null | undefined): BmiResult | null {
  if (!heightCm || !weightKg || heightCm <= 0 || weightKg <= 0) return null;

  const heightM = heightCm / 100;
  const raw = weightKg / (heightM * heightM);
  const value = Math.round(raw * 10) / 10;

  let category: BmiCategory;
  if (value < 18.5) category = "Underweight";
  else if (value < 25) category = "Normal";
  else if (value < 30) category = "Overweight";
  else category = "Obese";

  return { value, category };
}

export const BMI_LEGEND = [
  { label: "Underweight", range: "< 18.5" },
  { label: "Normal", range: "18.5 – 24.9" },
  { label: "Overweight", range: "25 – 29.9" },
  { label: "Obese", range: "≥ 30" },
] as const;
