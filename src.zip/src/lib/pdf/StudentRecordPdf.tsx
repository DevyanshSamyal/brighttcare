import React from "react";
import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";
import { SECTIONS, SECTION_ORDER } from "@/lib/sections";
import { formatFieldValue } from "@/lib/formatSectionValue";
import { calculateBmi, BMI_LEGEND } from "@/lib/bmi";
import type { SectionType, SectionStatus } from "@prisma/client";

const INK = "#16232A";
const INK_SOFT = "#4A5B62";
const PINE = "#0F6B5C";
const PINE_LIGHT = "#E4F0EC";
const MIST = "#E4E9E8";
const SLATE = "#5B6B72";
const SLATE_LIGHT = "#EEF2F2";

const styles = StyleSheet.create({
  page: { padding: 32, fontFamily: "Helvetica", fontSize: 9, color: INK },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 },
  logoBox: {
    width: 96,
    height: 40,
    borderWidth: 1,
    borderColor: PINE,
    borderRadius: 3,
    alignItems: "center",
    justifyContent: "center",
  },
  logoText: { fontFamily: "Times-Bold", fontSize: 12, color: PINE, letterSpacing: 1 },
  titleBlock: { alignItems: "flex-end" },
  title: { fontFamily: "Times-Bold", fontSize: 15, color: INK },
  subtitle: { fontSize: 8, color: INK_SOFT, marginTop: 2 },
  divider: { borderBottomWidth: 1.5, borderBottomColor: PINE, marginBottom: 10 },

  infoCard: {
    borderWidth: 1,
    borderColor: MIST,
    borderRadius: 4,
    padding: 8,
    marginBottom: 12,
    flexDirection: "row",
    flexWrap: "wrap",
  },
  infoItem: { width: "33%", marginBottom: 6, paddingRight: 6 },
  infoLabel: { fontSize: 7, color: INK_SOFT, textTransform: "uppercase", letterSpacing: 0.5 },
  infoValue: { fontSize: 9.5, fontFamily: "Courier", marginTop: 1 },

  sectionBlock: { marginBottom: 10, breakInside: "avoid" },
  sectionHeader: {
    backgroundColor: PINE,
    color: "#FFFFFF",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 3,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  sectionHeaderText: { fontFamily: "Times-Bold", fontSize: 11 },
  statusChip: { fontSize: 7.5, backgroundColor: "rgba(255,255,255,0.25)", paddingVertical: 2, paddingHorizontal: 6, borderRadius: 8 },
  absentNote: {
    marginTop: 6,
    backgroundColor: SLATE_LIGHT,
    borderRadius: 3,
    padding: 8,
    color: SLATE,
    fontSize: 9,
    fontStyle: "italic",
  },

  group: { marginTop: 6 },
  groupLabel: { fontSize: 8, fontFamily: "Helvetica-Bold", color: PINE, marginBottom: 3, textTransform: "uppercase", letterSpacing: 0.4 },
  fieldGrid: { flexDirection: "row", flexWrap: "wrap" },
  fieldItem: { width: "25%", marginBottom: 5, paddingRight: 4 },
  fieldItemWide: { width: "50%", marginBottom: 5, paddingRight: 4 },
  fieldLabel: { fontSize: 7, color: INK_SOFT },
  fieldValue: { fontSize: 9, marginTop: 1 },
  remarksBox: { marginTop: 3, fontSize: 8.5, color: INK_SOFT, fontStyle: "italic" },

  bmiRow: { flexDirection: "row", alignItems: "center", marginTop: 4, marginBottom: 2 },
  bmiValue: { fontFamily: "Times-Bold", fontSize: 14, color: PINE },
  bmiCategory: {
    marginLeft: 8,
    fontSize: 8,
    backgroundColor: PINE_LIGHT,
    color: PINE,
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 8,
  },
  legendRow: { flexDirection: "row", marginTop: 4, borderTopWidth: 0.5, borderTopColor: MIST, paddingTop: 4 },
  legendItem: { fontSize: 6.5, color: INK_SOFT, marginRight: 10 },

  footer: {
    position: "absolute",
    bottom: 20,
    left: 32,
    right: 32,
    flexDirection: "row",
    justifyContent: "space-between",
    fontSize: 7,
    color: INK_SOFT,
    borderTopWidth: 0.5,
    borderTopColor: MIST,
    paddingTop: 4,
  },
});

function fmtDate(d: Date | string | null | undefined) {
  if (!d) return "—";
  const date = new Date(d);
  return date.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

interface Props {
  student: {
    name: string;
    rollNumber: string;
    admissionNumber: string;
    parentage: string;
    gender: string;
    mobileNumber: string;
    examinationDate: Date | string | null;
    medicalOfficerName: string | null;
    class: { grade: string; section: string; school: { name: string } };
  };
  records: Record<SectionType, Record<string, unknown> | null>;
  statuses: Record<SectionType, SectionStatus>;
  generatedAt: Date;
}

export function StudentRecordPdf({ student, records, statuses, generatedAt }: Props) {
  const genExam = records.GENERAL_EXAM;
  const bmi = genExam ? calculateBmi(genExam.heightCm as number | null, genExam.weightKg as number | null) : null;

  return (
    <Document title={`${student.name} — Health Screening Record`}>
      <Page size="A4" style={styles.page}>
        <View style={styles.headerRow}>
          <View style={styles.logoBox}>
            <Text style={styles.logoText}>BRIGHTTCARE</Text>
          </View>
          <View style={styles.titleBlock}>
            <Text style={styles.title}>Student Health Screening Record</Text>
            <Text style={styles.subtitle}>{student.class.school.name}</Text>
          </View>
        </View>
        <View style={styles.divider} />

        <View style={styles.infoCard}>
          <InfoItem label="Name" value={student.name} />
          <InfoItem label="Class" value={`${student.class.grade}-${student.class.section}`} />
          <InfoItem label="Roll No." value={student.rollNumber} />
          <InfoItem label="Admission No." value={student.admissionNumber} />
          <InfoItem label="Gender" value={student.gender.charAt(0) + student.gender.slice(1).toLowerCase()} />
          <InfoItem label="Parent / Guardian" value={student.parentage} />
          <InfoItem label="Mobile" value={student.mobileNumber} />
          <InfoItem label="Examination Date" value={fmtDate(student.examinationDate)} />
          <InfoItem label="Medical Officer" value={student.medicalOfficerName || "—"} />
        </View>

        {SECTION_ORDER.map((section) => {
          const def = SECTIONS[section];
          const status = statuses[section];
          const record = records[section];

          return (
            <View key={section} style={styles.sectionBlock} wrap={false}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>{def.label}</Text>
                <Text style={styles.statusChip}>{status === "ABSENT" ? "Absent" : "Completed"}</Text>
              </View>

              {status === "ABSENT" || !record ? (
                <Text style={styles.absentNote}>Student was absent for this section.</Text>
              ) : (
                <>
                  {section === "GENERAL_EXAM" && bmi && (
                    <View>
                      <View style={styles.bmiRow}>
                        <Text style={styles.bmiValue}>BMI: {bmi.value}</Text>
                        <Text style={styles.bmiCategory}>{bmi.category}</Text>
                      </View>
                      <View style={styles.legendRow}>
                        {BMI_LEGEND.map((l) => (
                          <Text key={l.label} style={styles.legendItem}>
                            {l.label}: {l.range}
                          </Text>
                        ))}
                      </View>
                    </View>
                  )}

                  {def.groups
                    .filter((g) => g.label !== "Notes")
                    .map((group) => (
                      <View key={group.label} style={styles.group}>
                        <Text style={styles.groupLabel}>{group.label}</Text>
                        <View style={styles.fieldGrid}>
                          {group.fields.map((f) => {
                            const wide = f.type === "text" || f.type === "textarea";
                            return (
                              <View key={f.key} style={wide ? styles.fieldItemWide : styles.fieldItem}>
                                <Text style={styles.fieldLabel}>{f.label}</Text>
                                <Text style={styles.fieldValue}>{formatFieldValue(section, f.key, record[f.key])}</Text>
                              </View>
                            );
                          })}
                        </View>
                      </View>
                    ))}

                  {!!record.remarks && (
                    <Text style={styles.remarksBox}>Remarks: {String(record.remarks)}</Text>
                  )}
                </>
              )}
            </View>
          );
        })}

        <View style={styles.footer} fixed>
          <Text>Generated by Brighttcare on {fmtDate(generatedAt)}</Text>
          <Text render={({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`} />
        </View>
      </Page>
    </Document>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.infoItem}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue}>{value}</Text>
    </View>
  );
}
