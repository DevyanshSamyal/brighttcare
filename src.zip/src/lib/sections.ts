import type { SectionType } from "@prisma/client";

export type FieldType = "yesno" | "select" | "number" | "text" | "textarea";

export interface FieldOption {
  value: string;
  label: string;
}

export interface FieldDef {
  /** Matches the Prisma column name on the section's record model. */
  key: string;
  label: string;
  type: FieldType;
  options?: FieldOption[];
  unit?: string;
  placeholder?: string;
  /** Everything is required for a section to count as COMPLETE, except remarks. */
  required?: boolean;
}

export interface FieldGroup {
  label: string;
  fields: FieldDef[];
}

export interface SectionDef {
  key: SectionType;
  label: string;
  shortLabel: string;
  groups: FieldGroup[];
}

const yesNo: FieldOption[] = [
  { value: "YES", label: "Yes" },
  { value: "NO", label: "No" },
];

const abnormality: FieldOption[] = [
  { value: "NO_ABNORMALITY", label: "No Abnormality" },
  { value: "ABNORMALITY", label: "Abnormality" },
];

const normalAbnormalSpeech: FieldOption[] = [
  { value: "NO_ABNORMALITY", label: "Normal" },
  { value: "ABNORMALITY", label: "Abnormal" },
];

const visionScale: FieldOption[] = [
  { value: "V_1_6", label: "1/6" },
  { value: "V_2_6", label: "2/6" },
  { value: "V_3_6", label: "3/6" },
  { value: "V_4_6", label: "4/6" },
  { value: "V_5_6", label: "5/6" },
  { value: "V_6_6", label: "6/6" },
];

const tonsils: FieldOption[] = [
  { value: "ENLARGED", label: "Enlarged" },
  { value: "NOT_ENLARGED", label: "Not Enlarged" },
];

const presence: FieldOption[] = [
  { value: "PRESENT", label: "Present" },
  { value: "ABSENT", label: "Absent" },
];

export const REMARKS_FIELD: FieldDef = {
  key: "remarks",
  label: "Remarks",
  type: "textarea",
  required: false,
  placeholder: "Optional notes for this student's section",
};

export const SECTIONS: Record<SectionType, SectionDef> = {
  GENERAL_EXAM: {
    key: "GENERAL_EXAM",
    label: "General Examination",
    shortLabel: "General",
    groups: [
      {
        label: "Vitals",
        fields: [
          { key: "heightCm", label: "Height", type: "number", unit: "cm", required: true },
          { key: "weightKg", label: "Weight", type: "number", unit: "kg", required: true },
        ],
      },
      {
        label: "General",
        fields: [
          { key: "nailsHairSkin", label: "Nails / Hair / Skin", type: "select", options: abnormality, required: true },
          { key: "anemiaFigure", label: "Anemia / Figure", type: "select", options: yesNo, required: true },
          { key: "allergy", label: "Allergy", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "Abdomen",
        fields: [
          { key: "abdomenSoft", label: "Soft", type: "select", options: yesNo, required: true },
          { key: "abdomenHard", label: "Hard", type: "select", options: yesNo, required: true },
          { key: "abdomenDistended", label: "Distended", type: "select", options: yesNo, required: true },
          { key: "abdomenBowelSound", label: "Bowel Sound", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "CNS",
        fields: [
          { key: "cnsConscious", label: "Conscious", type: "select", options: yesNo, required: true },
          { key: "cnsOriented", label: "Oriented", type: "select", options: yesNo, required: true },
          { key: "cnsPlayful", label: "Playful", type: "select", options: yesNo, required: true },
          { key: "cnsActive", label: "Active", type: "select", options: yesNo, required: true },
          { key: "cnsAlert", label: "Alert", type: "select", options: yesNo, required: true },
          { key: "cnsSpeech", label: "Speech", type: "select", options: normalAbnormalSpeech, required: true },
        ],
      },
      {
        label: "Past History",
        fields: [
          { key: "pastHistoryMedical", label: "Medical", type: "select", options: yesNo, required: true },
          { key: "pastHistorySurgical", label: "Surgical", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "Other Readings",
        fields: [
          { key: "bp", label: "BP", type: "text", placeholder: "e.g. 110/70 or NA", required: true },
          { key: "pulse", label: "Pulse", type: "text", placeholder: "e.g. 82 or NA", required: true },
          { key: "hip", label: "Hip", type: "text", placeholder: "e.g. 74 or NA", required: true },
          { key: "waist", label: "Waist", type: "text", placeholder: "e.g. 64 or NA", required: true },
        ],
      },
      { label: "Notes", fields: [REMARKS_FIELD] },
    ],
  },

  ENT: {
    key: "ENT",
    label: "ENT",
    shortLabel: "ENT",
    groups: [
      {
        label: "Right Ear",
        fields: [
          { key: "rightEarDeformity", label: "Deformity", type: "select", options: yesNo, required: true },
          { key: "rightEarWax", label: "Wax", type: "select", options: yesNo, required: true },
          { key: "rightEarDischarge", label: "Discharge", type: "select", options: yesNo, required: true },
          { key: "rightEarNormalHearing", label: "Normal Hearing", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "Left Ear",
        fields: [
          { key: "leftEarDeformity", label: "Deformity", type: "select", options: yesNo, required: true },
          { key: "leftEarWax", label: "Wax", type: "select", options: yesNo, required: true },
          { key: "leftEarDischarge", label: "Discharge", type: "select", options: yesNo, required: true },
          { key: "leftEarNormalHearing", label: "Normal Hearing", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "Tympanic Membrane",
        fields: [{ key: "tympanicMembraneNormal", label: "Normal", type: "select", options: yesNo, required: true }],
      },
      {
        label: "Right Nose",
        fields: [
          { key: "rightNoseObstruction", label: "Nasal Obstruction", type: "select", options: yesNo, required: true },
          { key: "rightNoseDischarge", label: "Discharge", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "Left Nose",
        fields: [
          { key: "leftNoseObstruction", label: "Nasal Obstruction", type: "select", options: yesNo, required: true },
          { key: "leftNoseDischarge", label: "Discharge", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "Throat & Neck",
        fields: [
          { key: "throatPain", label: "Throat Pain", type: "select", options: yesNo, required: true },
          { key: "tonsils", label: "Tonsils", type: "select", options: tonsils, required: true },
          { key: "neckNodes", label: "Neck Nodes", type: "select", options: presence, required: true },
        ],
      },
      { label: "Notes", fields: [REMARKS_FIELD] },
    ],
  },

  VISION: {
    key: "VISION",
    label: "Vision / Ophthalmology",
    shortLabel: "Vision",
    groups: [
      {
        label: "Visual Acuity",
        fields: [
          { key: "reVision", label: "Right Eye (RE)", type: "select", options: visionScale, required: true },
          { key: "leVision", label: "Left Eye (LE)", type: "select", options: visionScale, required: true },
        ],
      },
      {
        label: "Color Blindness",
        fields: [
          { key: "colorBlindnessRE", label: "Right Eye (RE)", type: "select", options: yesNo, required: true },
          { key: "colorBlindnessLE", label: "Left Eye (LE)", type: "select", options: yesNo, required: true },
        ],
      },
      {
        label: "Squint",
        fields: [
          { key: "squintRE", label: "Right Eye (RE)", type: "select", options: yesNo, required: true },
          { key: "squintLE", label: "Left Eye (LE)", type: "select", options: yesNo, required: true },
        ],
      },
      { label: "Notes", fields: [REMARKS_FIELD] },
    ],
  },

  DENTAL: {
    key: "DENTAL",
    label: "Dental",
    shortLabel: "Dental",
    groups: [
      {
        label: "Extra-Oral",
        fields: [{ key: "extraOral", label: "Extra-Oral Examination", type: "select", options: abnormality, required: true }],
      },
      {
        label: "Cavities (Intra-Oral)",
        fields: [
          {
            key: "permanentCavities",
            label: "Permanent Teeth — Affected Tooth Numbers",
            type: "text",
            placeholder: "e.g. 16, 26, 36 — leave as \u201cNone\u201d if none",
            required: true,
          },
          {
            key: "primaryCavities",
            label: "Primary Teeth — Affected Tooth Numbers",
            type: "text",
            placeholder: "e.g. 55, 65 — leave as \u201cNone\u201d if none",
            required: true,
          },
        ],
      },
      {
        // (c)-(n) on the source form. (c) Plaque and (n) Missing Teeth were
        // confirmed directly; the ten in between are a best-guess list for a
        // standard Indian school dental screen — verify against the real form.
        label: "Findings",
        fields: [
          { key: "plaque", label: "Plaque", type: "select", options: yesNo, required: true },
          { key: "gumDisease", label: "Gum Disease / Gingivitis", type: "select", options: yesNo, required: true },
          { key: "gumBleeding", label: "Gum Bleeding", type: "select", options: yesNo, required: true },
          { key: "stains", label: "Stains", type: "select", options: yesNo, required: true },
          { key: "malocclusion", label: "Malocclusion", type: "select", options: yesNo, required: true },
          { key: "mouthBreathing", label: "Mouth Breathing", type: "select", options: yesNo, required: true },
          { key: "oralHygienePoor", label: "Oral Hygiene Poor", type: "select", options: yesNo, required: true },
          { key: "halitosis", label: "Halitosis (Bad Breath)", type: "select", options: yesNo, required: true },
          { key: "cleftLipPalate", label: "Cleft Lip / Palate", type: "select", options: yesNo, required: true },
          { key: "tongueTie", label: "Tongue Tie", type: "select", options: yesNo, required: true },
          { key: "ulcersLesions", label: "Ulcers / Lesions", type: "select", options: yesNo, required: true },
          { key: "missingTeeth", label: "Missing Teeth", type: "select", options: yesNo, required: true },
        ],
      },
      { label: "Notes", fields: [REMARKS_FIELD] },
    ],
  },
};

export const SECTION_ORDER: SectionType[] = ["GENERAL_EXAM", "ENT", "VISION", "DENTAL"];

export function getRequiredFieldKeys(section: SectionType): string[] {
  return SECTIONS[section].groups.flatMap((g) => g.fields.filter((f) => f.required).map((f) => f.key));
}

export function allFieldKeys(section: SectionType): string[] {
  return SECTIONS[section].groups.flatMap((g) => g.fields.map((f) => f.key));
}
