import { prisma } from "./prisma";
import type { SectionType } from "@prisma/client";

interface LogParams {
  userId: string;
  userName: string;
  action: string;
  studentId?: string;
  section?: SectionType;
  detail?: Record<string, unknown>;
}

export async function logAudit(params: LogParams) {
  await prisma.auditLog.create({
    data: {
      userId: params.userId,
      userName: params.userName,
      action: params.action,
      studentId: params.studentId,
      section: params.section,
      detail: params.detail as any,
    },
  });
}
