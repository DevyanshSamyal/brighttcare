import { prisma } from "./prisma";
import type { SectionType, SectionStatus } from "@prisma/client";

export async function getSectionRecord(studentId: string, section: SectionType) {
  switch (section) {
    case "GENERAL_EXAM":
      return prisma.generalExamRecord.findUnique({ where: { studentId } });
    case "ENT":
      return prisma.entRecord.findUnique({ where: { studentId } });
    case "VISION":
      return prisma.visionRecord.findUnique({ where: { studentId } });
    case "DENTAL":
      return prisma.dentalRecord.findUnique({ where: { studentId } });
  }
}

export async function upsertSectionRecord(
  studentId: string,
  section: SectionType,
  fields: Record<string, unknown>,
  status: SectionStatus,
  updatedBy: string
) {
  const data = { ...fields, status, updatedBy };
  switch (section) {
    case "GENERAL_EXAM":
      return prisma.generalExamRecord.upsert({
        where: { studentId },
        create: { studentId, ...data },
        update: data,
      });
    case "ENT":
      return prisma.entRecord.upsert({
        where: { studentId },
        create: { studentId, ...data },
        update: data,
      });
    case "VISION":
      return prisma.visionRecord.upsert({
        where: { studentId },
        create: { studentId, ...data },
        update: data,
      });
    case "DENTAL":
      return prisma.dentalRecord.upsert({
        where: { studentId },
        create: { studentId, ...data },
        update: data,
      });
  }
}

/** Clears clinical fields and sets status ABSENT — used by the "mark absent" action. */
export async function markSectionAbsent(studentId: string, section: SectionType, updatedBy: string) {
  const data = { status: "ABSENT" as SectionStatus, updatedBy };
  switch (section) {
    case "GENERAL_EXAM":
      return prisma.generalExamRecord.upsert({ where: { studentId }, create: { studentId, ...data }, update: data });
    case "ENT":
      return prisma.entRecord.upsert({ where: { studentId }, create: { studentId, ...data }, update: data });
    case "VISION":
      return prisma.visionRecord.upsert({ where: { studentId }, create: { studentId, ...data }, update: data });
    case "DENTAL":
      return prisma.dentalRecord.upsert({ where: { studentId }, create: { studentId, ...data }, update: data });
  }
}

export function sectionStatus(section: SectionType, s: {
  generalExam?: { status: SectionStatus } | null;
  ent?: { status: SectionStatus } | null;
  vision?: { status: SectionStatus } | null;
  dental?: { status: SectionStatus } | null;
}): SectionStatus {
  switch (section) {
    case "GENERAL_EXAM":
      return s.generalExam?.status ?? "PENDING";
    case "ENT":
      return s.ent?.status ?? "PENDING";
    case "VISION":
      return s.vision?.status ?? "PENDING";
    case "DENTAL":
      return s.dental?.status ?? "PENDING";
  }
}
