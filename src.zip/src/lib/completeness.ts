import { getRequiredFieldKeys } from "./sections";
import type { SectionType } from "@prisma/client";

/**
 * A section only counts as COMPLETE once every required field is filled.
 * This runs on every save — there's deliberately no separate "mark complete"
 * action (saving is enough); status is just derived from what's actually
 * been entered.
 */
export function isSectionDataComplete(section: SectionType, data: Record<string, unknown>): boolean {
  const required = getRequiredFieldKeys(section);
  return required.every((key) => {
    const value = data[key];
    return value !== null && value !== undefined && value !== "";
  });
}
