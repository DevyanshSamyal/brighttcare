import { getServerSession } from "next-auth";
import { authOptions } from "./auth";
import type { SectionType } from "@prisma/client";

export class PermissionError extends Error {
  status: number;
  constructor(message: string, status = 403) {
    super(message);
    this.status = status;
  }
}

export async function requireSession() {
  const session = await getServerSession(authOptions);
  if (!session?.user) throw new PermissionError("Not signed in", 401);
  return session;
}

export async function requireAdmin() {
  const session = await requireSession();
  if (session.user.role !== "ADMIN") throw new PermissionError("Admin access required", 403);
  return session;
}

/** Admin can touch every section; a doctor only their assigned section(s). */
export async function requireSectionAccess(section: SectionType) {
  const session = await requireSession();
  if (session.user.role === "ADMIN") return session;
  if (session.user.role === "DOCTOR" && session.user.sections.includes(section)) return session;
  throw new PermissionError("You don't have access to this section", 403);
}

export function jsonError(error: unknown) {
  if (error instanceof PermissionError) {
    return { body: { error: error.message }, status: error.status };
  }
  console.error(error);
  return { body: { error: "Something went wrong" }, status: 500 };
}
