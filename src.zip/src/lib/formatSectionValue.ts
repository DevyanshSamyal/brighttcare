import { SECTIONS, type FieldDef } from "./sections";
import type { SectionType } from "@prisma/client";

export function findFieldDef(section: SectionType, key: string): FieldDef | undefined {
  for (const group of SECTIONS[section].groups) {
    const field = group.fields.find((f) => f.key === key);
    if (field) return field;
  }
  return undefined;
}

export function formatFieldValue(section: SectionType, key: string, value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  const field = findFieldDef(section, key);
  if (!field) return String(value);

  if (field.type === "select" || field.type === "yesno") {
    const opt = field.options?.find((o) => o.value === value);
    return opt?.label ?? String(value);
  }
  if (field.type === "number") {
    return field.unit ? `${value} ${field.unit}` : String(value);
  }
  return String(value);
}
