"use client";

import { signOut } from "next-auth/react";
import Link from "next/link";

export function TopNav({ name, roleLabel }: { name: string; roleLabel: string }) {
  return (
    <header className="sticky top-0 z-10 bg-card border-b border-mist">
      <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full border-2 border-pine flex items-center justify-center">
            <span className="font-display font-bold text-pine text-xs">B</span>
          </div>
          <span className="font-display font-semibold text-ink">Brighttcare</span>
          <span className="text-xs text-ink-soft bg-mist rounded-full px-2 py-0.5 ml-1">{roleLabel}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-ink-soft hidden sm:inline">{name}</span>
          <Link href="/account" className="text-xs text-pine hover:underline">
            Account
          </Link>
          <button onClick={() => signOut({ callbackUrl: "/login" })} className="btn-secondary !py-1.5 !px-3 text-xs">
            Sign out
          </button>
        </div>
      </div>
    </header>
  );
}
