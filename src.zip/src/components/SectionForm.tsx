"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import type { SectionType } from "@prisma/client";
import { SECTIONS } from "@/lib/sections";
import { FormField } from "./FormField";
import { SectionStatusPill } from "./SectionStamp";
import { calculateBmi, BMI_LEGEND } from "@/lib/bmi";

interface StudentHeader {
  id: string;
  name: string;
  rollNumber: string;
  admissionNumber: string;
  class: { grade: string; section: string; school: { name: string } };
}

interface Props {
  studentId: string;
  section: SectionType;
  backHref: string;
}

export function SectionForm({ studentId, section, backHref }: Props) {
  const def = SECTIONS[section];
  const [student, setStudent] = useState<StudentHeader | null>(null);
  const [status, setStatus] = useState<"PENDING" | "COMPLETE" | "ABSENT">("PENDING");
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/students/${studentId}/sections/${section}`)
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        if (data.error) {
          setMessage({ type: "err", text: data.error });
          return;
        }
        setStudent(data.student);
        setStatus(data.record?.status ?? "PENDING");
        const initial: Record<string, string> = {};
        if (data.record) {
          for (const group of def.groups) {
            for (const field of group.fields) {
              const v = data.record[field.key];
              initial[field.key] = v === null || v === undefined ? "" : String(v);
            }
          }
        }
        setValues(initial);
      })
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [studentId, section, def.groups]);

  const bmi = useMemo(() => {
    if (section !== "GENERAL_EXAM") return null;
    const h = values.heightCm ? Number(values.heightCm) : null;
    const w = values.weightKg ? Number(values.weightKg) : null;
    return calculateBmi(h, w);
  }, [section, values.heightCm, values.weightKg]);

  async function save() {
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch(`/api/students/${studentId}/sections/${section}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data: values }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({ type: "err", text: data.error || "Couldn't save — try again." });
        return;
      }
      setStatus(data.record.status);
      setMessage({
        type: "ok",
        text: data.record.status === "COMPLETE" ? "Saved — section complete." : "Saved — some required fields are still empty.",
      });
    } finally {
      setSaving(false);
    }
  }

  async function markAbsent() {
    if (!confirm(`Mark ${student?.name ?? "this student"} absent for ${def.label}?`)) return;
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch(`/api/students/${studentId}/sections/${section}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ markAbsent: true }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({ type: "err", text: data.error || "Couldn't update — try again." });
        return;
      }
      setStatus("ABSENT");
      setMessage({ type: "ok", text: "Marked absent for this section." });
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="p-8 text-center text-ink-soft text-sm">Loading…</div>;
  }

  if (!student) {
    return (
      <div className="p-8 text-center">
        <p className="text-rose text-sm mb-3">{message?.text ?? "Couldn't load this student."}</p>
        <Link href={backHref} className="btn-secondary">
          Back
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto pb-24">
      <div className="flex items-center justify-between mb-4">
        <Link href={backHref} className="text-sm text-ink-soft hover:text-pine">
          ← Back
        </Link>
        <SectionStatusPill status={status} />
      </div>

      <div className="card p-4 mb-5">
        <p className="font-display text-lg text-ink">{student.name}</p>
        <p className="text-sm text-ink-soft font-mono">
          Roll {student.rollNumber} · Class {student.class.grade}-{student.class.section} · {student.class.school.name}
        </p>
      </div>

      {status === "ABSENT" && (
        <div className="mb-5 rounded-md bg-slate-light border border-slate/20 px-4 py-3 text-sm text-slate">
          This student is marked <strong>absent</strong> for {def.label}. Filling in fields below and saving will
          switch it back to an active record.
        </div>
      )}

      <h1 className="font-display text-xl font-semibold text-ink mb-4">{def.label}</h1>

      <div className="space-y-6">
        {def.groups.map((group) => (
          <div key={group.label} className="card p-4">
            <h2 className="text-xs font-semibold uppercase tracking-wide text-pine mb-3">{group.label}</h2>

            {group.label === "Vitals" && bmi && (
              <div className="flex items-center gap-3 mb-4 flex-wrap">
                <div>
                  <span className="font-display text-2xl font-semibold text-pine">{bmi.value}</span>
                  <span className="text-xs text-ink-soft ml-1">BMI</span>
                </div>
                <span className="rounded-full bg-pine-light text-pine text-xs px-2.5 py-1 font-medium">
                  {bmi.category}
                </span>
                <div className="flex gap-3 flex-wrap ml-auto text-[11px] text-ink-soft">
                  {BMI_LEGEND.map((l) => (
                    <span key={l.label}>
                      {l.label} {l.range}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {group.fields.map((field) => (
                <div key={field.key} className={field.type === "textarea" ? "sm:col-span-2" : ""}>
                  <FormField
                    field={field}
                    value={values[field.key]}
                    onChange={(v) => setValues((prev) => ({ ...prev, [field.key]: v }))}
                    disabled={saving}
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {message && (
        <p className={`mt-4 text-sm rounded-md px-3 py-2 ${message.type === "ok" ? "bg-pine-light text-pine" : "bg-rose-light text-rose"}`}>
          {message.text}
        </p>
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-mist px-4 py-3 flex items-center justify-between gap-3 sm:pl-[calc(theme(spacing.4))]">
        <button onClick={markAbsent} disabled={saving} className="btn-secondary">
          Mark Absent
        </button>
        <button onClick={save} disabled={saving} className="btn-primary flex-1 sm:flex-none sm:min-w-[160px]">
          {saving ? "Saving…" : "Save"}
        </button>
      </div>
    </div>
  );
}
