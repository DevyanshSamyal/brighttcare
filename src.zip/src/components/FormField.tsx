import type { FieldDef } from "@/lib/sections";

interface Props {
  field: FieldDef;
  value: unknown;
  onChange: (value: string) => void;
  disabled?: boolean;
}

export function FormField({ field, value, onChange, disabled }: Props) {
  const stringValue = value === null || value === undefined ? "" : String(value);

  return (
    <div>
      <label className="field-label">
        {field.label}
        {field.required && <span className="text-rose ml-0.5">*</span>}
      </label>

      {field.type === "select" && (
        <select
          className="field-input"
          value={stringValue}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
        >
          <option value="">Select…</option>
          {field.options?.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      )}

      {field.type === "number" && (
        <div className="relative">
          <input
            type="number"
            step="0.1"
            className="field-input"
            value={stringValue}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
          />
          {field.unit && (
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-ink-soft pointer-events-none">
              {field.unit}
            </span>
          )}
        </div>
      )}

      {field.type === "text" && (
        <input
          type="text"
          className="field-input font-mono"
          placeholder={field.placeholder}
          value={stringValue}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
        />
      )}

      {field.type === "textarea" && (
        <textarea
          className="field-input min-h-[70px] resize-y"
          placeholder={field.placeholder}
          value={stringValue}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
        />
      )}
    </div>
  );
}
