import type { SectionStatus } from "@prisma/client";

const CONFIG: Record<SectionStatus, { bg: string; border: string; text: string; icon: string; label: string }> = {
  COMPLETE: { bg: "#0F6B5C", border: "#0F6B5C", text: "#FFFFFF", icon: "check", label: "Complete" },
  ABSENT: { bg: "#5B6B72", border: "#5B6B72", text: "#FFFFFF", icon: "dash", label: "Absent" },
  PENDING: { bg: "transparent", border: "#CBD5D3", text: "#5B6B72", icon: "none", label: "Pending" },
};

export function SectionStamp({ status, size = 22 }: { status: SectionStatus; size?: number }) {
  const c = CONFIG[status];
  return (
    <span
      title={c.label}
      style={{
        width: size,
        height: size,
        backgroundColor: c.bg,
        borderColor: c.border,
      }}
      className="inline-flex items-center justify-center rounded-full border-2 shrink-0"
    >
      {c.icon === "check" && (
        <svg width={size * 0.55} height={size * 0.55} viewBox="0 0 16 16" fill="none">
          <path d="M3 8.5L6.2 11.5L13 4.5" stroke={c.text} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
      {c.icon === "dash" && (
        <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 16 16" fill="none">
          <path d="M3 8H13" stroke={c.text} strokeWidth="2" strokeLinecap="round" />
        </svg>
      )}
    </span>
  );
}

export function SectionStatusPill({ status }: { status: SectionStatus }) {
  const c = CONFIG[status];
  const bg = status === "PENDING" ? "#EEF2F2" : c.bg;
  const fg = status === "PENDING" ? "#5B6B72" : c.text;
  return (
    <span
      style={{ backgroundColor: bg, color: fg }}
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium"
    >
      <SectionStamp status={status} size={14} />
      {c.label}
    </span>
  );
}
