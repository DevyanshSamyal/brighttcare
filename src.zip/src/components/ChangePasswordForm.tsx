"use client";

import { useState, FormEvent } from "react";

export function ChangePasswordForm() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setMessage(null);

    if (newPassword !== confirmPassword) {
      setMessage({ type: "err", text: "New password and confirmation don't match." });
      return;
    }

    setSaving(true);
    const res = await fetch("/api/account/password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword, newPassword }),
    });
    const data = await res.json();
    setSaving(false);

    if (!res.ok) {
      setMessage({ type: "err", text: data.error || "Couldn't update your password." });
      return;
    }

    setMessage({ type: "ok", text: "Password updated." });
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  }

  return (
    <form onSubmit={handleSubmit} className="card p-4 max-w-md space-y-4">
      <div>
        <label className="field-label">Current Password</label>
        <input
          type="password"
          className="field-input"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          autoComplete="current-password"
          required
        />
      </div>
      <div>
        <label className="field-label">New Password</label>
        <input
          type="password"
          className="field-input"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          autoComplete="new-password"
          minLength={6}
          required
        />
      </div>
      <div>
        <label className="field-label">Confirm New Password</label>
        <input
          type="password"
          className="field-input"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          autoComplete="new-password"
          minLength={6}
          required
        />
      </div>

      {message && (
        <p className={`text-sm rounded-md px-3 py-2 ${message.type === "ok" ? "bg-pine-light text-pine" : "bg-rose-light text-rose"}`}>
          {message.text}
        </p>
      )}

      <button className="btn-primary" disabled={saving}>
        {saving ? "Updating…" : "Update Password"}
      </button>
    </form>
  );
}
